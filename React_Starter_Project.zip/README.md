# React Starter Project

Простой стартовый проект на React для загрузки на GitHub и демонстрации работодателям.